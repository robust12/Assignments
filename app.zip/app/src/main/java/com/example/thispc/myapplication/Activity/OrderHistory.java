package com.example.thispc.myapplication.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.example.thispc.myapplication.Adapter.OrderHistoryAdapter;
import com.example.thispc.myapplication.Model.New_Item_Object;
import com.example.thispc.myapplication.SharedPrefs.OrderShared_Pref;
import com.example.thispc.myapplication.R;

import java.util.ArrayList;

public class OrderHistory extends AppCompatActivity {

    ListView orderListView;
    ArrayList<New_Item_Object> orderlist;
    OrderShared_Pref newpref;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
        newpref = new OrderShared_Pref(OrderHistory.this);
        toolbar = (Toolbar)findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Order History");
        toolbar.setTitleTextColor(0xFFFFFFFF);

        if(newpref.IsOrderPlaced()) {
            newpref.updateorderdetails();

            orderlist = newpref.getOrderedProductDetails();
            orderListView = (ListView) findViewById(R.id.OrderIdlist);
            orderListView.setAdapter(new OrderHistoryAdapter(OrderHistory.this, orderlist));
        }else{
            TextView norder = (TextView)findViewById(R.id.noOrderPlaced);
            norder.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
