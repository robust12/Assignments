package com.example.thispc.myapplication.Helper;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import org.apache.commons.lang.StringEscapeUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;
import org.w3c.dom.Document;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by This pc on 20-08-2016.
 */
public class UtilClass {

    //to Parse The  Json Object From Urll
    public static JSONObject getJSONFromUrl(String completeurl){
        InputStream is = null;

        JSONObject jsonObject=null;
        String jsonstring="";
        try {
            URL url = new URL(completeurl);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);

            is = new BufferedInputStream(urlConnection.getInputStream());
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            if(s.hasNext()){
                jsonstring= s.next();
            }
            urlConnection.disconnect();
        } catch (MalformedURLException e) {
            //Log.d("error", "error in getjsonfromurl MalformedUrlexception");
        }

        catch(SocketTimeoutException r){

            Log.e("Socket", "error in timeout");
            r.printStackTrace();

        }catch (IOException e){
            Log.d("error", "error in getjsonfromurl Ioexception");

        }
        try {


            jsonstring=StringEscapeUtils.unescapeHtml(jsonstring);
            jsonObject = new JSONObject(jsonstring);
        } catch (JSONException e) {
            // Log.d("error", "Json exception");
        }
        return jsonObject;
    }

    //to Check Whether Connection Is Available
    public static Boolean isNetworkAvailable(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo  = connectivityManager.getActiveNetworkInfo();
        return networkInfo!=null && networkInfo.isConnected();
    }

    public static int API_Version(){
        String currentapiVersion = Build.VERSION.RELEASE;
        currentapiVersion.trim();
        Number number;
        int val=6;
        try {
             number = NumberFormat.getInstance().parse(currentapiVersion);
            val = number.intValue();
        }catch (Exception e){
            e.printStackTrace();
        }

        Log.e("API"," "+val);
        return val;
    }

    public static void show_dialog(Context context,String title ,String message,String pb,String nb){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        // set title
        alertDialogBuilder.setTitle(title);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(pb,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {

                    }
                })
                .setNegativeButton(nb,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


}
