package com.example.thispc.myapplication.Helper;

import android.util.Log;

import com.example.thispc.myapplication.OAuthProvider;

import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;

/**
 * Created by This pc on 20-08-2016.
 */
public class Constants {

    public static final String baseImageUrl = "http://www.24groz7.com/admin_area/product_images/";
    public static final String baseLoginRequestUrl = "http://www.24groz7.com/api-service/login.php?mail=";
    public static final String baseNewUserRequestUrl = "http://www.24groz7.com/api-service/register.php?name=";
    public static final String baseOrderUrl = "http://www.24groz7.com/api-service/cart.php?data=";
    public static String baseUrl = "";



    public static final String CategoryUrl1 = "http://storetodoor.online/wp-json/wc/v1/products/categories?oauth_consumer_key=ck_08c3c4bc6b0f11d7a63f28a510186392981682e4&oauth_signature_method=HMAC-SHA1&oauth_timestamp=1473083647&oauth_nonce=T2f1dV&oauth_version=1.0&oauth_signature=Tuf1icCexVOnqfYrj%2B2AF2N9m3Y%3D";
    public static final String CategoryUrl2 = "http://www.24groz7.com/api-service/products_category.php?id=2";
    public static final String CategoryUrl3 = "http://www.24groz7.com/api-service/products_category.php?id=3";
    public static final String CategoryUrl4 = "http://www.24groz7.com/api-service/products_category.php?id=4";
    public static final String CategoryUrl5 = "http://www.24groz7.com/api-service/products_category.php?id=5";
    public static final String CategoryUrl6 = "http://www.24groz7.com/api-service/products_category.php?id=6";
    public static final String CategoryUrl7 = "http://www.24groz7.com/api-service/products_category.php?id=7";
    public static final String CategoryUrl8 = "http://www.24groz7.com/api-service/products_category.php?id=8";
    public static final String CategoryUrl9 = "http://www.24groz7.com/api-service/products_category.php?id=10";
    public static final String CategoryUrl10 = "http://www.24groz7.com/api-service/products_category.php?id=11";
    public static final String CategoryUrl11= "http://www.24groz7.com/api-service/products_category.php?id=12";
    public static final String CategoryUrl12 = "http://www.24groz7.com/api-service/products_category.php?id=13";
    public static final String CategoryUrl13 = "http://www.24groz7.com/api-service/products_category.php?id=14";
    public static final String CategoryUrl14 = "http://www.24groz7.com/api-service/products_category.php?id=15";
    public static final String CategoryUrl15 = "http://www.24groz7.com/api-service/products_category.php?id=16";



    public static final String baseSearchUrl = "http://www.24groz7.com/api-service/search.php?search=";

    public static void set_Url(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String consumerKey    = "ck_08c3c4bc6b0f11d7a63f28a510186392981682e4"; //api key
                String consumerSecret = "cs_e6b7b77c2834320429b2ea782b068d610de1b4e5"; //api secret
                String requestUrl = "http://storetodoor.online/wp-json/wc/v1/products?category=319";

                OAuthService service = new ServiceBuilder()
                        .provider(OAuthProvider.instance())
                        .signatureType(SignatureType.QueryString)
                        .apiKey(consumerKey)
                        .apiSecret(consumerSecret)
                        .build()
                        ;

                OAuthRequest request = new OAuthRequest(Verb.GET, requestUrl);
                Token accessToken = new Token("", ""); //not required for context.io
                service.signRequest(accessToken, request);

                Response response = request.send();
                Log.e("OAuthTask", response.getBody());
            }
        }).start();
    }
}
