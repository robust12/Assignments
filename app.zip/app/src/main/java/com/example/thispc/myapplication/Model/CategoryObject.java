package com.example.thispc.myapplication.Model;

import java.io.Serializable;

/**
 * Created by a.subal on 10/6/2016.
 */
public class CategoryObject implements Serializable {
    int id ;
    String name ;
    String slug ;
    int parentId ;
    String description;
    String imageUrl;

    public CategoryObject(int id, String name, String slug, int parentId, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.slug = slug;
        this.parentId = parentId;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSlug() {
        return slug;
    }

    public int getParentId() {
        return parentId;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
