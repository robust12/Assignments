package com.example.thispc.myapplication.SharedPrefs;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.thispc.myapplication.Model.New_Item_Object;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by j.prasad on 07-09-2016.
 */
public class OrderShared_Pref {
    private static final String SHARED_PREF_NAME = "ORDER_DETAILS";
    private static final String NAME_OF_ORDER_LIST = "ORDER_LIST";

    //declaration
    public Context context;
    Gson gson;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    JSONObject orderdetailsJsonObject;
    ArrayList<New_Item_Object> item_objects;

    public OrderShared_Pref(Context context){
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        gson = new Gson();
        item_objects = new ArrayList<>();
        //JSON_ITEM_LIST = new JSONObject(item_objects);
    }


    public void add_order_details(JSONObject jsonObject){
        editor.putString(NAME_OF_ORDER_LIST,jsonObject.toString());
        editor.commit();
    }

    public void updateorderdetails(){
        JSONObject jsonObject = null;
        String result = (sharedPreferences.getString(NAME_OF_ORDER_LIST,""));
        try {
            jsonObject = new JSONObject(result);
        }catch (JSONException e){
            e.printStackTrace();
        }
        orderdetailsJsonObject = jsonObject;
    }

    public JSONObject getorderdetails(){
        JSONObject jsonObject = null;
        String result = (sharedPreferences.getString(NAME_OF_ORDER_LIST,""));
        try {
            jsonObject = new JSONObject(result);
        }catch (JSONException e){
            e.printStackTrace();
        }
        return jsonObject;
    }

    public String getOrderId(){
        String res = "";
        try {
             res = orderdetailsJsonObject.getString("id");
        }catch (JSONException e){
            e.printStackTrace();
        }
        return res;
    }
    public ArrayList<New_Item_Object> getOrderedProductDetails(){
        ArrayList<New_Item_Object> arrayList = new ArrayList<>();
        New_Item_Object tmp = new New_Item_Object();
        try {
            JSONArray array = orderdetailsJsonObject.getJSONArray("line_items");
            int len = array.length();
            for(int i=0;i < len;i++){
                String name = array.getJSONObject(i).getString("name");
                String quantity = array.getJSONObject(i).getString("quantity");
                String price = array.getJSONObject(i).getString("price");
                tmp = new New_Item_Object(name,price,"",Integer.parseInt(quantity),"");
                arrayList.add(tmp);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
        return arrayList;
    }

    public boolean IsOrderPlaced(){
        JSONObject jsonObject = new JSONObject();
        boolean flag = true;
        jsonObject = getorderdetails();
        if(jsonObject == null)
            flag  = false;

        return flag;
    }


}
