package com.example.thispc.myapplication.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


import com.example.thispc.myapplication.Adapter.vertical_product_adapter;
import com.example.thispc.myapplication.Helper.Constants;
import com.example.thispc.myapplication.Helper.UtilClass;
import com.example.thispc.myapplication.Model.Product_Sample_Object;
import com.example.thispc.myapplication.OAuthProvider;
import com.example.thispc.myapplication.R;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import org.json.JSONArray;
import org.json.JSONObject;
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by a.subal on 10/7/2016.
 */
public class ProductPlaceholderFragment extends Fragment {
    /**
     * The fragment argument representing the section number for this
     * fragment.
     */
    Toolbar toolbar;
    private String TAG = "Product_show_Activity";
    private TextView noInternet;
    private Button Refresh;
    private ImageLoaderConfiguration config;
    private vertical_product_adapter adapter;
    private static final String ARG_SECTION_NUMBER = "section_number";
    private static int category_id ;
    private ListView verticalprodList ;
    static ArrayList<Product_Sample_Object>ProdList ;
    public ProductPlaceholderFragment() {
    }
    /**
     * Returns a new instance of this fragment for the given section
     * number.
     */
    public static ProductPlaceholderFragment newInstance(int sectionNumber,ArrayList<Product_Sample_Object>prodList) {
        ProductPlaceholderFragment fragment = new ProductPlaceholderFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
       // category_id = categoryId ;
        ProdList = prodList ;
        return fragment;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_product_show_, container, false);
//        TextView textView = (TextView) rootView.findViewById(R.id.section_label);
//        textView.setText(getString(R.string.section_format, getArguments().getInt(ARG_SECTION_NUMBER)));
        verticalprodList =(ListView) rootView.findViewById(R.id.verticalprodList);
        noInternet = (TextView) rootView.findViewById(R.id.noInternet);
        Refresh = (Button) rootView.findViewById(R.id.refresh);
        if(ProdList.isEmpty())
        {   noInternet.setText("Oops Nothing Here");
            noInternet.setVisibility(View.VISIBLE);

        }
        else {
            adapter = new vertical_product_adapter(getActivity(), ProdList);
            verticalprodList.setAdapter(adapter);
        }
//        if(UtilClass.isNetworkAvailable(getActivity())) {
//
//
//            new Async_Task_JsonParser(getActivity()).execute(Constants.CategoryUrl1);
//        }
        return rootView;
    }
//    public class Async_Task_JsonParser extends AsyncTask<String,Void,List<Product_Sample_Object> > {
//        Context context;
//
//        public Async_Task_JsonParser(Context context){
//            this.context = getActivity();
//        }
//
//        ProgressDialog progressBar;
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            progressBar = new ProgressDialog(context,R.style.AppCompatAlertDialogStyle);
//            progressBar.setCancelable(false);
//            if(UtilClass.API_Version()<6) {
//                progressBar.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
//            }
//            progressBar.setMessage("Getting Products");
//            progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//            progressBar.setProgress(0);
//            progressBar.setMax(100);
//            progressBar.show();
//
//        }
//
//        @Override
//        protected void onPostExecute(List<Product_Sample_Object> resultantProductList) {
//            super.onPostExecute(resultantProductList);
//            Log.e(TAG,"inside postExecute for "+category_id);
//            if(progressBar != null && progressBar.isShowing()){
//                progressBar.dismiss();
//            }
//            if (resultantProductList.isEmpty()){
//                Log.e("Present", "Present Hai ye");
//                noInternet.setText("Oops Nothing Found ");
//                noInternet.setVisibility(View.VISIBLE);
//            //    Refresh.setVisibility(View.VISIBLE);
//
//                //  dialog.cancel();
//            }
//            else{
//
//            }
//
//        }
//
//        @Override
//        protected List<Product_Sample_Object> doInBackground(String... params) {
//            List<Product_Sample_Object> resultantProductList = new ArrayList<Product_Sample_Object>();
//
//            JSONObject jsonObj;
//            JSONArray array = null;
//            try{
//                String consumerKey    = "ck_08c3c4bc6b0f11d7a63f28a510186392981682e4"; //api key
//                String consumerSecret = "cs_e6b7b77c2834320429b2ea782b068d610de1b4e5"; //api secret
//                int k = 1;
//                while(true) {
//                    String requestUrl = "http://storetodoor.online/wp-json/wc/v1/products?category=" + category_id + "&per_page=100&page="+k;
//
//                    OAuthService service = new ServiceBuilder()
//                            .provider(OAuthProvider.instance())
//                            .signatureType(SignatureType.QueryString)
//                            .apiKey(consumerKey)
//                            .apiSecret(consumerSecret)
//                            .build();
//
//                    OAuthRequest request = new OAuthRequest(Verb.GET, requestUrl);
//                    Token accessToken = new Token("", ""); //not required for context.io
//                    service.signRequest(accessToken, request);
//
//                    Response response = request.send();
//
//                    String res = response.getBody();
//                    Log.e(TAG,"COUNT "+ k + "\n" +res+"\n");
//                    //JSONObject object = (JSONObject) new JSONTokener(res).nextValue();
//                    //jsonObj = new JSONObject(res);
//                    if(response.getBody() == null || response.getBody() == " " || response == null){
//                        break;
//                    }
//                    if(array == null) {
//                        array = new JSONArray(res);
//                    }
//                    else{
//                        JSONArray tmp = new JSONArray(res);
//                        if(tmp.length() == 0){
//                            break;
//                        }
//                        array.put(new JSONArray(res));
//                    }
//                    k++;
//                    Log.e(TAG,"COUNT "+ k);
//                }
//                Log.e(TAG," "+array.length()+ " " + array);
//                // for(int i=0;i < array.length();i++){
//                //     Log.e(TAG," "+array.getJSONObject(i)+"\n");
//                // }
//                for(int i=0;i < array.length();i++) {
//                    jsonObj = array.getJSONObject(i);
//                    JSONArray img = jsonObj.getJSONArray("images");
//                    Log.e(TAG, "sd" + jsonObj);
//                    String name = jsonObj.getString("name");
//                    String Product_id = jsonObj.getString("id");
//                    String cost_price = jsonObj.getString("price");
//                    String Sale_price = jsonObj.getString("regular_price");
//                    String img_url = img.getJSONObject(0).getString("src");
//                    String quantity = jsonObj.getString("stock_quantity");
//                    resultantProductList.add(new Product_Sample_Object(name, cost_price, Sale_price, Product_id, 0, img_url, 0));
//                    Log.e("OAuthTask", "" + name + "\n" + Product_id + "\n" + cost_price + "\n" + Sale_price + "\n" + img_url + "\n" + quantity);
//                    Constants.baseUrl = img_url;
//                }
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//            return resultantProductList;
//        }
//    }

}



