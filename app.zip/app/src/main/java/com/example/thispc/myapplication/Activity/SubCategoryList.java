package com.example.thispc.myapplication.Activity;

import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.TextView;

import com.example.thispc.myapplication.Adapter.CategoryListAdapter;
import com.example.thispc.myapplication.Model.CategoryObject;
import com.example.thispc.myapplication.R;

/**
 * Created by a.subal on 10/7/2016.
 */
public class SubCategoryList extends AppCompatActivity {

    String TAG = "CategoryList";
    Toolbar toolbar;
    GridView subCategoryList ;
    CategoryObject parentCategory;
    DrawerLayout mDrawerLayout ;
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);
        toolbar  = (Toolbar) findViewById(R.id.toolbar_main);
        toolbar.setTitleTextColor(0xFFFFFFFF);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_toc_white_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        parentCategory = (CategoryObject) getIntent().getSerializableExtra("category");
        subCategoryList = (GridView)findViewById(R.id.categorygrid);
        subCategoryList.setNumColumns(1);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        subCategoryList.setAdapter(new CategoryListAdapter(SubCategoryList.this,CategoryListAdapter.SUB_CATEGORY,parentCategory.getId()));

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId() ;

        if (id == android.R.id.home) {
            mDrawerLayout.openDrawer(GravityCompat.START);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
