package com.example.thispc.myapplication.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.thispc.myapplication.Model.New_Item_Object;
import com.example.thispc.myapplication.SharedPrefs.OrderShared_Pref;
import com.example.thispc.myapplication.R;

import java.util.ArrayList;

/**
 * Created by j.prasad on 07-09-2016.
 */
public class OrderHistoryAdapter extends BaseAdapter {
    ArrayList<New_Item_Object> Products_list;
    private Context context;

    OrderShared_Pref newPref;

    public OrderHistoryAdapter(Context context, ArrayList<New_Item_Object> products_list) {
        this.context = context;
        this.Products_list = products_list;
    }

    public static class ViewHolder {
        public TextView quantity;
        public TextView itemprice;
        public TextView itemname;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = convertView;
        newPref = new OrderShared_Pref(context);

        ViewHolder viewHolder = new ViewHolder();
        if (convertView == null) {

            LayoutInflater cartInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = cartInflater.inflate(R.layout.orderhistory_single_item, parent, false);
            viewHolder.quantity = (TextView) v.findViewById(R.id.quantity);
            viewHolder.itemname = (TextView) v.findViewById(R.id.ordereditemname);
            viewHolder.itemprice = (TextView) v.findViewById(R.id.price);

            v.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) v.getTag();
        }
        //reference to all the views in the cart item
        //setting all the names, quantity, Price for the item of the cart ....by taking it from Shared Preference Json
        viewHolder.itemname.setText("" + Products_list.get(position).Name);
        viewHolder.quantity.setText("Quantity: " + Products_list.get(position).Quantity);
        viewHolder.itemprice.setText("₹" + Products_list.get(position).Price);
        //int price_val = ((int)Integer.parseInt(Products_list.get(position).Price));


        final ViewHolder finalViewHolder = viewHolder;
        return v;
    }
        @Override
        public Object getItem( int position){
            return null;
        }

        @Override
        public int getCount () {
            return Products_list.size();
        }

        @Override
        public long getItemId ( int position){
            return 0;
        }

}
