package com.example.thispc.myapplication.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.thispc.myapplication.Adapter.CategoryListAdapter;
import com.example.thispc.myapplication.Adapter.SlidePager;
import com.example.thispc.myapplication.Adapter.category_list_adapter;
import com.example.thispc.myapplication.Helper.UtilClass;
import com.example.thispc.myapplication.Model.Product_Sample_Object;
import com.example.thispc.myapplication.R;
import com.example.thispc.myapplication.SharedPrefs.Cart_Shared_Pref;
import com.example.thispc.myapplication.SharedPrefs.CategorySharedPref;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by a.subal on 10/5/2016.
 */
public class CategoryList extends AppCompatActivity {
    String TAG = "CategoryList";
    Toolbar toolbar;
    GridView categoryGrid ;
    ProgressDialog progressDialog;
    JSONObject categoryJson ;
    DrawerLayout mDrawerLayout ;
    NavigationView navigationView ;
    ViewPager imagePager ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);
        toolbar  = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_toc_white_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        imagePager = (ViewPager)findViewById(R.id.imagePager);
        final SlidePager imagePagerAdapter = new SlidePager(this);
        imagePager.setAdapter(imagePagerAdapter);



        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                int currentPage = 0 ;
                if (currentPage == SlidePager.PAgGECOUNT) {
                    currentPage = 0;
                }
                currentPage+=1;
                imagePager.setCurrentItem(currentPage, true);
            }
        };

        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 1000, 1000);


        toolbar.setTitleTextColor(0xFFFFFFFF);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView)findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int id = item.getItemId();
                switch (id){
                    case R.id.mycart:
                        Intent CartRedirect = new Intent(CategoryList.this,Cart.class);
                        CartRedirect.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(CartRedirect);
                        break;
                    case R.id.History:
                        Intent intent = new Intent(CategoryList.this,OrderHistory.class);
                        startActivity(intent);
                        break;
                    case R.id.help :
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(CategoryList.this);
                        alertDialogBuilder.setTitle("Help");
                        alertDialogBuilder
                                .setMessage("Having trouble,Please Contact at"+"\n +91 8053232232.")
                                .setCancelable(false)
                                .setPositiveButton("call",new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,int id) {
                                        Intent callIntent = new Intent(Intent.ACTION_CALL);
                                        callIntent.setData(Uri.parse("tel:8053232232"));
                                        if(ContextCompat.checkSelfPermission(CategoryList.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED){
                                            startActivity(callIntent);
                                        }
                                    }
                                })
                                .setNegativeButton("back",new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                        break;

                }
                return false;
            }
        });
        // Set the adapter for the list view
        categoryJson = null ;
        new Async_Task_JsonParser().execute();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId() ;

        if (id == android.R.id.home) {
            mDrawerLayout.openDrawer(GravityCompat.START);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class Async_Task_JsonParser extends AsyncTask<Void,Void,Void >{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        progressDialog = new ProgressDialog(CategoryList.this,R.style.AppCompatAlertDialogStyle);
        progressDialog.setCancelable(false);
            if(UtilClass.API_Version()<6) {
                progressDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            }
        progressDialog.setMessage("Getting Products");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        }

        @Override
        protected Void doInBackground(Void... voids) {
           categoryJson =  UtilClass.getJSONFromUrl("http://storetodoor.online/libd/example.php");
            Log.d(TAG,"The response received from the server is "+categoryJson.toString());
            CategorySharedPref sharedPref = new CategorySharedPref(CategoryList.this);
            sharedPref.saveCategoryData(categoryJson);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (categoryJson == null){
                Toast.makeText(CategoryList.this,"Unable to fetch data please try again",Toast.LENGTH_SHORT).show();
                }
            categoryGrid = (GridView)findViewById(R.id.categorygrid);
            categoryGrid.setAdapter(new CategoryListAdapter(CategoryList.this,CategoryListAdapter.BASE_CATEGORY,0));
            progressDialog.dismiss();
        }
    }

}
