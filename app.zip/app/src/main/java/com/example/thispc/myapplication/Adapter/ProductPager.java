package com.example.thispc.myapplication.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

//import com.example.thispc.myapplication.Activity.Category_list;
import com.example.thispc.myapplication.Fragment.ProductPlaceholderFragment;
import com.example.thispc.myapplication.Helper.Constants;
import com.example.thispc.myapplication.Helper.UtilClass;
import com.example.thispc.myapplication.Model.CategoryObject;
import com.example.thispc.myapplication.Model.Product_Sample_Object;
import com.example.thispc.myapplication.OAuthProvider;
import com.example.thispc.myapplication.R;
import com.example.thispc.myapplication.SharedPrefs.CategorySharedPref;

import org.json.JSONArray;
import org.json.JSONObject;
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by a.subal on 10/7/2016.
 */
public class ProductPager extends FragmentStatePagerAdapter {
    private final String TAG = "ProductPager";
    CategoryObject subCategory;
    CategorySharedPref categoryData ;
    Context context ;
    ArrayList<Product_Sample_Object>productList;

    ArrayList<CategoryObject> list ;
    public ProductPager(FragmentManager fm,CategoryObject subCategory,Context context,ArrayList<Product_Sample_Object> products) {
        super(fm);
        this.context = context ;
        this.subCategory = subCategory;
        categoryData = new CategorySharedPref(context);
        list =  categoryData.getCategoryList(subCategory.getId());
        productList =products ;
        list.add(categoryData.getCategory(subCategory.getId()));


    }



    @Override
    public int getCount() {
        // Show 3 total pages.
        return list.size();
    }
    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).
        int id = list.get(position).getId();
        ArrayList<Product_Sample_Object>prodList = new ArrayList<>();
        for(Product_Sample_Object product : productList){
            if(productBelongsTo(id,product)){
                prodList.add(product);
            }
        }
        return ProductPlaceholderFragment.newInstance(position + 1, prodList);
    }

    private boolean productBelongsTo(int id,Product_Sample_Object product) {
        for (Integer idx : product.getCategories()){
            if (idx == id ){
                return true;
            }
        }
        return false ;

    }

    @Override
    public CharSequence getPageTitle(int position) {
      return list.get(position).getName();
    }


}
