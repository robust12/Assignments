package com.example.thispc.myapplication.SharedPrefs;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.thispc.myapplication.Model.CategoryObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.ArrayList;

/**
 * Created by a.subal on 10/6/2016.
 */
public class CategorySharedPref {
    private final String CATEGORY_DATA ="categoryData";
    SharedPreferences sharedPreferences ;
    Context context;
    public CategorySharedPref(Context context) {
        this.context = context ;
    }
    public void saveCategoryData(JSONObject categoryList){
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(CATEGORY_DATA,categoryList.toString());
        editor.commit();


    }
    public  CategoryObject getCategory(int id){
          CategoryObject categoryObject = null ;
        sharedPreferences =PreferenceManager.getDefaultSharedPreferences(context);
        try {
            JSONObject json = new JSONObject(sharedPreferences.getString(CATEGORY_DATA, null));
            JSONArray categories = json.getJSONArray("product_categories");
            int length = categories.length();
            for (int idx = 0 ; idx < length ; idx++) {
                JSONObject category = categories.getJSONObject(idx);
               if( category.getInt("id") == id) {
                 categoryObject = new CategoryObject(category.getInt("id"), category.getString("name"),
                         category.getString("slug"), category.getInt("parent"), category.getString("description"),
                         category.getString("image"));
                   break;
               }

            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return  categoryObject ;
    }
    public ArrayList<CategoryObject> getCategoryList (int parentId){
        sharedPreferences =PreferenceManager.getDefaultSharedPreferences(context);
        ArrayList<CategoryObject> list = new ArrayList<CategoryObject>() ;

        try {
            JSONObject json = new JSONObject( sharedPreferences.getString(CATEGORY_DATA,null));
            JSONArray categories = json.getJSONArray( "product_categories");
            int length = categories.length();
            for (int idx = 0 ; idx < length ; idx++){
                JSONObject  category = categories.getJSONObject(idx);
                if(category.getInt("parent") == parentId) {
                    CategoryObject cat = new CategoryObject(category.getInt("id"), category.getString("name"),
                            category.getString("slug"), category.getInt("parent"), category.getString("description"),
                            category.getString("image"));
                    list.add(cat);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
       return list ;
    }

}
