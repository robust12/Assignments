package com.example.thispc.myapplication.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.thispc.myapplication.Adapter.cart_list_adapter;
import com.example.thispc.myapplication.SharedPrefs.Cart_Shared_Pref;
import com.example.thispc.myapplication.Helper.UtilClass;
import com.example.thispc.myapplication.Model.New_Item_Object;
import com.example.thispc.myapplication.R;
//import com.google.gson.Gson;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    private ListView cartlist;
    private TextView noInternetForCart;
    private Button cartzeroElements , checkButton;
    Cart_Shared_Pref newPref;
    ArrayList<New_Item_Object> Products_list;
    Toolbar toolbar ;

    //Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        toolbar  = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(0xFFFFFFFF);



                //gson = new Gson();
        newPref = new Cart_Shared_Pref(getBaseContext());

        Products_list = newPref.getItem_objects();
     //   noInternetForCart = (TextView)findViewById(R.id.noInternetForCart);
        cartzeroElements = (Button)findViewById(R.id.cartzeroElements);
        checkButton = (Button)findViewById(R.id.checkoutbutton);

        cartzeroElements.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LandingPage = new Intent(getApplicationContext(),CategoryList.class);
                LandingPage.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(LandingPage);
            }
        });

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(UtilClass.isNetworkAvailable(Cart.this)){
                    if (newPref.getCartSize()>0){
                        Intent LoginRedirect = new Intent(getApplicationContext(),OrderPlace.class);
                        startActivity(LoginRedirect);
                    }
                }
            }
        });

        if(UtilClass.isNetworkAvailable(this)) {
            if (newPref.getCartSize() > 0) {
                checkButton.setVisibility(View.VISIBLE);
                cartlist = (ListView) findViewById(R.id.cartlist);
                cartlist.setAdapter(new cart_list_adapter(this, Products_list));
                setTitle("Cart");
            }else {
                cartzeroElements.setText("ADD SOME ITEMS");
                cartzeroElements.setVisibility(View.VISIBLE);

            }
        }
        else{
            noInternetForCart.setText("Ooops...No Internet Connection");
            noInternetForCart.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_cart, menu);
        return true;
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home){
            Intent HomePageRedirect = new Intent(getApplicationContext(),CategoryList.class);
            HomePageRedirect.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(HomePageRedirect);
            return true;
        }
        else if (id == R.id.CheckOutMenuButton){
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
