package com.example.thispc.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.WindowManager;

import com.example.thispc.myapplication.Helper.UtilClass;

import org.json.JSONArray;
import org.json.JSONObject;
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;


public class getJsonAsyncTask extends AsyncTask<String,Void,JSONObject > {
        Context context;
        String TAG = "getJsonAsyncTask";
        public getJsonAsyncTask(Context context){
            this.context = context;
        }

        //        MaterialDialog dialog;
        ProgressDialog progressBar;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar = new ProgressDialog(context);
            progressBar.setCancelable(false);
            if(UtilClass.API_Version() < 6) {
                progressBar.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            }
            progressBar.setMessage("Getting Products");
            progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressBar.setProgress(0);
            progressBar.setMax(100);
            progressBar.show();
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);

            if(progressBar != null && progressBar.isShowing()){
                progressBar.dismiss();
            }
            if (jsonObject==null){
                Log.e("Present", "Present Hai ye");
                //  dialog.cancel();
            }
            else {

                // dialog.cancel();
            }
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            JSONObject jsonObject = null;
            JSONArray arr = null;
            try{
                String consumerKey    = "ck_08c3c4bc6b0f11d7a63f28a510186392981682e4"; //api key
                String consumerSecret = "cs_e6b7b77c2834320429b2ea782b068d610de1b4e5"; //api secret
                String requestUrl = params[0];
                Log.e(TAG," "+requestUrl);
                OAuthService service = new ServiceBuilder()
                        .provider(OAuthProvider.instance())
                        .signatureType(SignatureType.QueryString)
                        .apiKey(consumerKey)
                        .apiSecret(consumerSecret)
                        .build()
                        ;

                OAuthRequest request = new OAuthRequest(Verb.GET, requestUrl);
                Token accessToken = new Token("", ""); //not required for context.io
                service.signRequest(accessToken, request);

                Response response = request.send();
                String res = response.getBody();
                //JSONObject object = (JSONObject) new JSONTokener(res).nextValue();
                //jsonObj = new JSONObject(res);
                Log.e(TAG,"res "+ res);
                 jsonObject = new JSONObject(res);
                // for(int i=0;i < array.length();i++){
                //     Log.e(TAG," "+array.getJSONObject(i)+"\n");
                // }
            }catch (Exception e){
                e.printStackTrace();
            }
            return jsonObject;
        }
}
