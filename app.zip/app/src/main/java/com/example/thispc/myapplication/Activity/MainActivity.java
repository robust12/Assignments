package com.example.thispc.myapplication.Activity;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.thispc.myapplication.R;


public class MainActivity extends AppCompatActivity {

    public static final int SPLASH_TIME = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //getSupportActionBar().hide();

        new Handler().postDelayed(new Runnable() {
            public void run() {
                Intent MainPage = new Intent();
                MainPage.setClass(getApplicationContext(), CategoryList.class);
             //   MainPage.setClass(getApplicationContext(), Category_list.class);
                MainPage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(MainPage);
                MainActivity.this.finish();
                // transition from splash screen to Category List
                //   overridePendingTransition(R.xml.fadein, R.xml.fadeout);
            }
        }, SPLASH_TIME);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
