package com.example.thispc.myapplication.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.thispc.myapplication.Model.Address_Object;
import com.example.thispc.myapplication.R;
import com.example.thispc.myapplication.SharedPrefs.Address_Shared_Pref;

import java.util.ArrayList;

/**
 * Created by arcks on 9/10/16.
 */
public class Order extends AppCompatActivity {
    Address_Shared_Pref addressData ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_place);
        addressData = new Address_Shared_Pref(this);
        if(!addressData.getAddress_objects_list().isEmpty()){
            AlertDialog dialog = new AlertDialog.Builder(this).create();
            dialog.setTitle("Do you want us to deliver at this address ?");
            ArrayList<Address_Object> addresses = addressData.getAddress_objects_list();
            Address_Object address = addresses.get(addresses.size()-1);
            dialog.setMessage(address.getFull_name()+"\n"+address.getAddress()+"\n"+address.getPhone()+"\n"+address.getEmail());

            dialog.setButton(DialogInterface.BUTTON_POSITIVE, "YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "NO",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
        }

    }
}
