package com.example.thispc.myapplication.SharedPrefs;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.thispc.myapplication.Model.Address_Object;
import com.example.thispc.myapplication.Model.New_Item_Object;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Created by j.prasad on 09-09-2016.
 */
public class Address_Shared_Pref {
    private static final String SHARED_PREF_NAME = "ADDRESS";
    private static final String NAME_OF_ADDRESS_LIST = "ADDRESS_DETAIL";





    public Context context;
    Gson gson;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    ArrayList<Address_Object> address_objects_list;
    String JSON_ADDRESS;

    public Address_Shared_Pref(Context context) {

        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        gson = new Gson();
        this.context = context;
        address_objects_list = new ArrayList<>();
        JSON_ADDRESS =gson.toJson(address_objects_list);

    }

    public ArrayList<Address_Object> getAddress_objects_list(){
        ArrayList<Address_Object> list = new ArrayList<>();
        String json = sharedPreferences.getString(NAME_OF_ADDRESS_LIST,"");
        Type type = new TypeToken<ArrayList<Address_Object>>(){}.getType();
        list = gson.fromJson(json, type);
        return list;
    }
    public void saveAddress(Address_Object newAddress){
        editor = sharedPreferences.edit();
        editor.putString("address",gson.toJson(newAddress));
        editor.commit();

    }
    public Address_Object getAddress (){
     String jsonString = sharedPreferences.getString("address",null);
        if ( jsonString ==null)
            return null ;
        else
          return gson.fromJson(jsonString,Address_Object.class);

    }



    public void setAddress_objects_list(Address_Object new_address_object){
            ArrayList<Address_Object> list= new ArrayList<>();
            list = getAddress_objects_list();
            /** Check Whether Address Object already exists or not **/
            if(!list.contains(new_address_object)){
                list.add(new_address_object);
            }
            String updated_list = gson.toJson(list);
            editor.putString(NAME_OF_ADDRESS_LIST,updated_list);
            editor.commit();
    }

}
