package com.example.thispc.myapplication.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.thispc.myapplication.Model.Address_Object;
import com.example.thispc.myapplication.SharedPrefs.Address_Shared_Pref;
import com.example.thispc.myapplication.SharedPrefs.Cart_Shared_Pref;
import com.example.thispc.myapplication.Helper.UtilClass;
import com.example.thispc.myapplication.SharedPrefs.OrderShared_Pref;
import com.example.thispc.myapplication.R;
//import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
/**
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.SignatureType;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;
**/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class OrderPlace extends AppCompatActivity {


    Cart_Shared_Pref newPref;
    Button newuser, confirmorder;
    EditText username, password;
    TextView totalPrice, shippingHint, paybleamount, hintExtra;
    EditText ename, eaddress, ephone, eemail, ecity, estate, epincode;
    String Order_Api = "";
    String TAG = "ORDERPLACE";
    Address_Shared_Pref addressData ;


    public static String order_data = "";
    static JSONArray place_order_data;
    public static boolean IS_ORDER_PLACED = false; // Used in OrderHistory

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_place);

        setUpRefrences();



        addressData = new Address_Shared_Pref(this);

        if(addressData.getAddress() != null){
            Address_Object address = addressData.getAddress();
            ename.setText(address.getAddress());
            ephone.setText(address.getPhone());
            ecity.setText(address.getCity());
            estate.setText(address.getState());
            eemail.setText(address.getEmail());
            eaddress.setText(address.getAddress());
            epincode.setText(address.getPincode());
        }


                    confirmorder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // ASYNC TASK FOR PLACING ORDER FROM CART
                    orderFormation();
                    Toast.makeText(getApplicationContext(), "Wait", Toast.LENGTH_SHORT);
                    (new Async_Task_orderPlace(OrderPlace.this)).execute(Order_Api);
                }
            });

    }

    private void setUpRefrences() {
        newPref = new Cart_Shared_Pref(getApplicationContext());
        place_order_data = new JSONArray();
        totalPrice = (TextView) findViewById(R.id.totalamountString);
        shippingHint = (TextView) findViewById(R.id.ShippingHint);
        paybleamount = (TextView) findViewById(R.id.paybleAmount);
        hintExtra = (TextView) findViewById(R.id.hintExtra);
        confirmorder = (Button) findViewById(R.id.ConfirmOrder);
        ename = (EditText) findViewById(R.id.fullnameinput);
        eaddress = (EditText) findViewById(R.id.addressinput);
        ephone = (EditText) findViewById(R.id.phoneinput);
        eemail = (EditText) findViewById(R.id.emailinput);
        ecity = (EditText) findViewById(R.id.cityinput);
        estate = (EditText) findViewById(R.id.stateinput);
        epincode = (EditText) findViewById(R.id.pincodeinput);
        totalPrice.setTextColor(getResources().getColor(R.color.material_blue_grey_800));
        totalPrice.setText("Total Price : ₹" + newPref.getTotalPrice());

        if (newPref.getTotalPrice() > 250) {
            paybleamount.setText("Amount Payble : ₹ " + newPref.getTotalPrice());
            shippingHint.setText("*Delievery Charges : ₹" + 0);
        } else {
            paybleamount.setText("Amount payble : ₹" + (newPref.getTotalPrice() + 25));
            shippingHint.setTextColor(getResources().getColor(R.color.material_blue_grey_800));
            shippingHint.setText("Delievery Charges : ₹" + 25);
        }
    }

    private void orderFormation() {
        String name = ename.getText().toString();
        String address = eaddress.getText().toString();
        String phone = ephone.getText().toString();
        String email = eemail.getText().toString();
        String city = ecity.getText().toString();
        String state = estate.getText().toString();
        String pincode = epincode.getText().toString();
        Address_Object address_object = new Address_Object(name,phone,address,city,state,pincode,email);
        addressData.saveAddress(address_object);
      //  addressData.setAddress_objects_list(address_object);

        Log.e(TAG + "1st", " " + ename.getText() + " " + eaddress.getText());
        Order_Api = "http://storetodoor.online/libd/order.php?name=" + name + "&address=" + address + "&city=" + city + "&state=" + state + "&pincode=" + pincode + "&country=India&email=" + email + "&phone =" + phone;

        // Product ID And Quantities JSON
        order_data = "sa";
        place_order_data = newPref.getProductID();
        order_data = place_order_data.toString();
        Log.e(TAG, " " + order_data);

    }

    public class Async_Task_orderPlace extends AsyncTask<String, Void, JSONObject> {
        Context context;

        public Async_Task_orderPlace(Context context) {
            this.context = context;
        }

        ProgressDialog progressBar;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar = new ProgressDialog(context);
            progressBar.setCancelable(false);
            if (UtilClass.API_Version() < 6)
                progressBar.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
            progressBar.setMessage("Please Wait...");
            progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressBar.setProgress(0);
            progressBar.setMax(100);
            progressBar.show();

        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);
            if (progressBar != null && progressBar.isShowing()) {
                progressBar.dismiss();
            }
            String message = "";
            String pb = "",nb= "";
            try {
                if (jsonObject != null) {
                    String id1 = jsonObject.getString("id");
                    Log.e(TAG, " " + id1);
                    /**Storing SuccessFull Order Details ,To Show in ORDER HISTORY**/
                    OrderShared_Pref orderShared_pref = new OrderShared_Pref(OrderPlace.this);
                    orderShared_pref.add_order_details(jsonObject);
                    orderShared_pref.updateorderdetails();

                    message = "Your Order is placed successfully";
                    pb = "Continue Shopping";
                    IS_ORDER_PLACED = true;
                    /** Delete Cart Once Order Is Placed **/
                    Cart_Shared_Pref pref = new Cart_Shared_Pref(OrderPlace.this);
                    pref.deleteCart();
                } else {
                    message = "There is some problem while placing your order, Please Try Again";
                    pb = "Retry";
                }

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                alertDialogBuilder.setTitle("Order Status");
                alertDialogBuilder
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton(pb,new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                  Intent OrderSuccessfull = new Intent(OrderPlace.this, CategoryList.class);
                                  startActivity(OrderSuccessfull);
                            }
                        })
                        .setNegativeButton(nb,new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                clearFields(); /** For Clearing TextViews **/
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected JSONObject doInBackground(String... params) {

            JSONObject jsonObj = null;
            JSONArray array = null;
            try {
                jsonObj = getJSONFromUrl(params[0]);
                Log.e(TAG, "URL " + params[0]);
                Log.e(TAG, "result " + jsonObj);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return jsonObj;
        }
    }

    public static JSONObject getJSONFromUrl(String completeurl) throws IOException, JSONException, MalformedURLException {
        HttpURLConnection httpcon;
        String url = completeurl;
        String data = "";
        String result = null;
        try {
            //Connect
            httpcon = (HttpURLConnection) ((new URL(url).openConnection()));
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            httpcon.setRequestProperty("Accept", "application/json");
            httpcon.setRequestMethod("POST");
            httpcon.connect();
            //Write
            OutputStream os = httpcon.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(order_data);
            writer.close();
            os.close();

            //Read
            BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream(), "UTF-8"));
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            result = sb.toString();
            Log.e("res", " " + result);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new JSONObject(result);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            Intent HomePageRedirect = new Intent(getApplicationContext(), Cart.class);
            HomePageRedirect.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(HomePageRedirect);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        Intent goBack = new Intent(getApplicationContext(), Cart.class);
        goBack.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(goBack);
        this.finish();
    }
    public void clearFields(){
        ename.setText("");
        eaddress.setText("");
        ecity.setText("");
        estate.setText("");
        eemail.setText("");
        ephone.setText("");
        epincode.setText("");
    }

}