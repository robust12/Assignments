package com.example.thispc.myapplication.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by This pc on 20-08-2016.
 */
public class Product_Sample_Object implements Serializable{
    private String ProductName;
    private String CostPrize;
    private String SellPrize;
    private int Discount;
    private String ImageUrl;
    private int Quantity;
    private String ProductId;
    private List<Integer> categories;

    public Product_Sample_Object(String productName, String costPrize, String sellPrize,
                                 String productId, int discount,String imageUrl,int quantity,
                                 ArrayList<Integer> cats) {
        super();

        this.ProductName = productName;
        this.CostPrize = costPrize;
        this.SellPrize = sellPrize;
        this.ProductId = productId;
        this.Discount = discount;
        this.ImageUrl = imageUrl;
        this.Quantity = quantity;
        categories = cats ;
    }

    public String getProductName() {
        return ProductName;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public String getCostPrize() {
        return CostPrize;
    }

    public String getSellPrize() {
        return SellPrize;
    }

    public int getDiscount() {
        return Discount;
    }

    public String getProductId(){return ProductId;}

    public List<Integer> getCategories() {
        return categories;
    }

    public int getQuantity(){return Quantity;}

    public void setQuantity(int quantity){
        this.Quantity = quantity;
    }

}
