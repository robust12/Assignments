package com.example.thispc.myapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//import com.example.thispc.myapplication.Activity.Product_show_Activity;
import com.example.thispc.myapplication.Activity.Products;
import com.example.thispc.myapplication.Activity.SubCategoryList;
import com.example.thispc.myapplication.Model.CategoryObject;
import com.example.thispc.myapplication.R;
import com.example.thispc.myapplication.SharedPrefs.CategorySharedPref;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by a.subal on 10/5/2016.
 */
public class CategoryListAdapter extends BaseAdapter {
    public static final int BASE_CATEGORY = 1;
    public static final int SUB_CATEGORY = 2;
    public static final int SUB_SUB_CATEGORY = 3;
    Context context ;
    ArrayList<CategoryObject>list ;
    CategorySharedPref sharedPref ;
//     Image Loading Part
    private ImageLoaderConfiguration config;
    private File cacheDir;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private int level;



    public CategoryListAdapter(Context context,int level,int parent) {
     this.context = context;
     this.level = level ;
     sharedPref = new CategorySharedPref(context);
     // passing 0 as the parent id because we want all the categories which are at the base level
     list = sharedPref.getCategoryList(parent);
     //    Image Loading Part
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(ImageLoaderConfiguration.createDefault(context));
        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED))
            cacheDir = new File(android.os.Environment.getExternalStorageDirectory(), "storeToDoor");
        else
            cacheDir = context.getCacheDir();
        if (!cacheDir.exists())
            cacheDir.mkdirs();

        options = new DisplayImageOptions.Builder()
                .showImageOnLoading(R.drawable.splash_screen)
                .showImageOnFail(R.drawable.abc_textfield_activated_mtrl_alpha)
                .bitmapConfig(Bitmap.Config.RGB_565)
                .imageScaleType(ImageScaleType.IN_SAMPLE_INT)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .build();

        config = new ImageLoaderConfiguration.Builder(context)
                .memoryCache(new WeakMemoryCache())
                .denyCacheImageMultipleSizesInMemory()
                .threadPoolSize(5)
                .defaultDisplayImageOptions(options)
                .build();
        imageLoader.init(config);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        LayoutInflater categoryInflater =  (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rootView = categoryInflater.inflate(R.layout.category_custom_view,parent,false);

        final ImageView categorypic = (ImageView) rootView.findViewById(R.id.categorypic);
        TextView categoryname = (TextView) rootView.findViewById(R.id.categoryname);
        categoryname.setText(list.get(position).getName());
        categorypic.setImageResource(R.drawable.dals);
        if(level == BASE_CATEGORY){
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (context, SubCategoryList.class);
                intent .putExtra("category",list.get(position));
                context.startActivity(intent);

//                Intent intent = new Intent(context,Product_show_Activity.class);
//                intent.putExtra("position", "Grocery & Staples");
//                intent.putExtra("id", list.get(position).getId());
//                context.startActivity(intent);
            }
        });
        }
        if(level == SUB_CATEGORY)
        {
            ViewGroup.LayoutParams lp=categorypic.getLayoutParams();
            lp.width= ViewGroup.LayoutParams.MATCH_PARENT;
            categorypic.setLayoutParams(lp);
            //TODO: for moving from subcategory to product page take care of extra products as well\
            rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, Products.class);
                    intent.putExtra("subCategory", list.get(position));

                    context.startActivity(intent);
                }
            });
//
        }
        if (!list.get(position).getImageUrl().isEmpty())

        imageLoader.displayImage(list.get(position).getImageUrl(), categorypic, options, new ImageLoadingListener() {
          @Override
          public void onLoadingStarted(String s, View view) {

          }

          @Override
          public void onLoadingFailed(String s, View view, FailReason failReason) {

          }

          @Override
          public void onLoadingComplete(String s, View view, Bitmap bitmap) {

          }

          @Override
          public void onLoadingCancelled(String s, View view) {

          }
      });
        return rootView;
    }
}
