package com.example.thispc.myapplication.Model;

/**
 * Created by j.prasad on 09-09-2016.
 */
public class Address_Object {
        String full_name;
        String phone;
        String address;
        String city;
        String state;
        String pincode;
        String email;

        public Address_Object(String Name,String Phone,String Address,String City,String State,String Pin,String Email){
            this.full_name = Name;
            this.phone = Phone;
            this.address = Address;
            this.city = City;
            this.state = State;
            this.pincode = Pin;
            this.email = Email;
        }

    public void Set_Name(String name){
        full_name = name;
    }
    public void setAddress(String Address){
        address = Address;
    }
    public String GetAddress(){
        return address;
    }

    public String getFull_name() {
        return full_name;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getPincode() {
        return pincode;
    }

    public String getEmail() {
        return email;
    }
}
