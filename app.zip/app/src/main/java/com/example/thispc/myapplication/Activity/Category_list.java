//package com.example.thispc.myapplication.Activity;
//
//import android.Manifest;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.net.Uri;
//import android.os.AsyncTask;
//import android.support.v4.app.ActivityCompat;
//import android.support.v4.content.ContextCompat;
//import android.support.v7.app.AlertDialog;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.support.v7.widget.Toolbar;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.GridView;
//
//import com.example.thispc.myapplication.Adapter.category_list_adapter;
//import com.example.thispc.myapplication.Helper.Constants;
//import com.example.thispc.myapplication.R;
//import com.example.thispc.myapplication.getJsonAsyncTask;
//
//import org.json.JSONObject;
//
//public class Category_list extends AppCompatActivity {
//
//    GridView categorygrid;
//   // private vertical_product_adapter adapter;
//    static final String[] categorynameList = new String[] {"Grocery & Staples","Biscuits & Snacks","Drinks & Beverages","Fruits & vegetables","Daily Bakery","Ice Cream & Chocolate","Health & Nutrition","Branded Food","Branded Store","House Care & Utilites","Personal Care","Baby Care","Pet Care","Stationary"};
//    static final int [] categorypicList = new int[] {R.drawable.dals,R.drawable.wheat,R.drawable.oils,R.drawable.bevrages,R.drawable.spices,R.drawable.kitchen,R.drawable.patanjli,R.drawable.bakery,R.drawable.biscuit,R.drawable.dryfruits,R.drawable.pasta,R.drawable.bathroom,R.drawable.instant,R.drawable.personalcare,R.drawable.household};
//    static final int[] categoryIdList = new int[] {520,354,349,316,475,319,639,649,0,320,323,324,325,398};
//    String TAG = "Category_list";
//    Toolbar toolbar;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_category_list);
//        toolbar = (Toolbar) findViewById(R.id.toolbar_main);
//        setSupportActionBar(toolbar);
//        toolbar.setTitleTextColor(0xFFFFFFFF);
//
//        categorygrid = (GridView)findViewById(R.id.categorygrid);
//        categorygrid.setAdapter(new category_list_adapter(getApplicationContext(), categorynameList, categorypicList));
//
//        AsyncTask<String, Void, JSONObject> response = (new getJsonAsyncTask(Category_list.this)).execute(Constants.CategoryUrl1);
//
//        final Intent intent = new Intent(getApplicationContext(),Product_show_Activity.class);
//        categorygrid.setOnItemClickListener(
//                new AdapterView.OnItemClickListener() {
//                    @Override
//                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                        switch (position) {
//                            case 0:
//                                intent.putExtra("position", "Grocery & Staples");
//                                intent.putExtra("id", categoryIdList[0]);
//                                startActivity(intent);
//                                break;
//                            case 1:
//                                intent.putExtra("position", "Biscuits & Snacks");
//                                intent.putExtra("id", categoryIdList[1]);
//                                startActivity(intent);
//                                break;
//                            case 2:
//                                intent.putExtra("position", "Drinks & Beverages");
//                                intent.putExtra("id", categoryIdList[2]);
//                                startActivity(intent);
//                                break;
//                            case 3:
//                                intent.putExtra("position", "Fruits & vegetables");
//                                intent.putExtra("id", categoryIdList[3]);
//                                startActivity(intent);
//                                break;
//                            case 4:
//                                intent.putExtra("position", "Daily Bakery");
//                                intent.putExtra("id", categoryIdList[4]);
//                                startActivity(intent);
//                                break;
//                            case 5:
//                                intent.putExtra("position", "Ice Cream & Chocolate");
//                                intent.putExtra("id", categoryIdList[5]);
//                                startActivity(intent);
//                                break;
//                            case 6:
//                                intent.putExtra("position", "Health & Nutrition");
//                                intent.putExtra("id", categoryIdList[6]);
//                                startActivity(intent);
//                                break;
//                            case 7:
//                                intent.putExtra("position", "Branded Food");
//                                intent.putExtra("id", categoryIdList[7]);
//                                startActivity(intent);
//                                break;
//                            case 8:
//                                intent.putExtra("position", "Branded Store");
//                                intent.putExtra("id", categoryIdList[8]);
//                                startActivity(intent);
//                                break;
//                            case 9:
//                                intent.putExtra("position", "House Care & Utilites");
//                                intent.putExtra("id", categoryIdList[9]);
//                                startActivity(intent);
//                                break;
//                            case 10:
//                                intent.putExtra("position", "Personal Care");
//                                intent.putExtra("id", categoryIdList[10]);
//                                startActivity(intent);
//                                break;
//                            case 11:
//                                intent.putExtra("position", "Baby Care");
//                                intent.putExtra("id", categoryIdList[11]);
//                                startActivity(intent);
//                                break;
//                            case 12:
//                                intent.putExtra("position", "Pet Care");
//                                intent.putExtra("id", categoryIdList[12]);
//                                startActivity(intent);
//                                break;
//                            case 13:
//                                intent.putExtra("position", "Stationary");
//                                intent.putExtra("id", categoryIdList[13]);
//                                startActivity(intent);
//                                break;
//                            default:
//                                break;
//                        }
//                    }
//                }
//        );
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_category_list, menu);
//        return true;
//    }
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        switch(item.getItemId()){
//            case R.id.help:
//                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Category_list.this);
//                // set title
//                alertDialogBuilder.setTitle("Help");
//                alertDialogBuilder
//                        .setMessage("Finding any trouble,Please Contact at +91 8053232232.")
//                        .setCancelable(false)
//                        .setPositiveButton("Call",new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog,int id) {
//                                String helpline = "8053232232";
//                                String uri = "tel:" + helpline.trim() ;
//                                if ( ContextCompat.checkSelfPermission(Category_list.this, Manifest.permission.CALL_PHONE ) != PackageManager.PERMISSION_GRANTED ) {
//                                }
//                                Intent intent = new Intent(Intent.ACTION_CALL);
//                                intent.setData(Uri.parse(uri));
//                                startActivity(intent);
//                            }
//                        })
//                        .setNegativeButton("back",new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int id) {
//                                dialog.cancel();
//                            }
//                        });
//                AlertDialog alertDialog = alertDialogBuilder.create();
//                alertDialog.show();
//                return true;
//            case R.id.mycart:
//                Intent Cart = new Intent(getApplicationContext(),Cart.class);
//                startActivity(Cart);
//                return true;
//            case R.id.History:
//        //        alert.show();
//                Intent order_history = new Intent(Category_list.this,OrderHistory.class);
//                startActivity(order_history);
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);}
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//    }
//
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        this.finish();
//    }
//}
